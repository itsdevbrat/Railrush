import sys
#print(max , min , alreadyPT)
print("400,200,100")