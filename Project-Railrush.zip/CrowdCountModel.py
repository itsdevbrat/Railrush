import sys
print(sys.argv[1]+'     '+sys.argv[2])